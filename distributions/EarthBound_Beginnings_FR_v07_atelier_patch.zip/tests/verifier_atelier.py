#!/usr/bin/env python3
"""Refus d'import dangereux et aller-retour CSV sans modifier les sources."""
import copy
import csv
import hashlib
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'traduction'))
import atelier


def main():
    before = {name: hashlib.sha256((ROOT / 'traduction' / name).read_bytes()).hexdigest()
              for name in atelier.FILES.values()}
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / 'traductions.csv'
        atelier.export_csv(path)
        atelier.import_csv(path, apply=True)
        with path.open(encoding='utf-8-sig', newline='') as source:
            rows = list(csv.DictReader(source, delimiter=';'))

        def write(data):
            with path.open('w', encoding='utf-8-sig', newline='') as output:
                writer = csv.DictWriter(output, fieldnames=atelier.COLUMNS, delimiter=';')
                writer.writeheader(); writer.writerows(data)

        def refused(data):
            write(data)
            try:
                atelier.import_csv(path, apply=True)
            except ValueError:
                return
            raise AssertionError('Import invalide accepté')

        # Une modification valable au début ne doit pas être écrite si la suite échoue.
        for column, value in [('original', 'faux original'), ('id', 'FFFFFF'),
                              ('segment', '999999'), ('francais', '[1F 02 74]')]:
            changed = copy.deepcopy(rows)
            changed[0]['francais'] = 'Essai'
            changed[-1][column] = value
            refused(changed)
        refused([*rows, rows[0]])
        changed = copy.deepcopy(rows)
        psi = next(row for row in changed if atelier.NATIVE.search(row['original']))
        psi['francais'] = atelier.NATIVE.sub('', psi['francais'])
        refused(changed)

        # Un import partiel valide met à jour seulement le texte français.
        changed = [copy.deepcopy(rows[0])]
        changed[0]['francais'] = 'Essai'
        write(changed)
        sample = atelier.load()
        with patch.object(atelier, 'load', return_value=sample):
            atelier.import_csv(path)
        first = next(atelier.entries(sample))
        assert first[2] == 'Essai' and first[1] == rows[0]['original']
    after = {name: hashlib.sha256((ROOT / 'traduction' / name).read_bytes()).hexdigest()
             for name in atelier.FILES.values()}
    assert before == after, 'Sources modifiées pendant les refus ou l’aller-retour'
    print('Atelier : aller-retour, import partiel, 6 refus et sources intactes OK.')


if __name__ == '__main__':
    main()
